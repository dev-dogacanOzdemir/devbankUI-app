import  {Component} from 'react';

class CustomerDashboardPage extends Component {
    render() {
        return (
            <div>

            </div>
        );
    }
}

export default CustomerDashboardPage;